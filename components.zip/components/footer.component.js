import React, {useState} from 'react'
function Footer(){
    return(
        <div>
            Hello world
        </div>
    )
}

export default Footer;